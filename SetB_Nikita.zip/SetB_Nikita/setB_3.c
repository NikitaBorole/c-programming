#include<stdio.h>
unsigned int reverseBits(unsigned int value);
void displayBits(unsigned int value);
int main()
{
unsigned int a;
printf("%s","Enter an unsigned value : ");
scanf("%u",&a);
puts("Before reverse:\n");
displayBits(a);
a=reverseBits(a);
puts("After reverse:\n");
displayBits(a);
}

unsigned int reverseBits(unsigned int value)
{
unsigned int num = 1;
unsigned int temp = 0;
unsigned int i;
for(i=0;i<=3;i++)
{
temp<<=1;
temp |=(value & num);
value>>=1;
}
return temp;
}

void displayBits(unsigned int value)
{
unsigned int c;
unsigned int displaynum = 1<<3;
for (c=1;c<=4;++c)
{
value & displaynum ? putchar ('1') : putchar('0');
value<<=1;
if (c % 4 == 0)
putchar('\n');
}
}


