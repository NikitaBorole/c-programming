#include<stdio.h>
#include<stdlib.h>
void main()
{
	int n,i,j,count=0,flag=0;
	printf("Enter the number of elements in string\n");
	scanf("%d",&n);
	char temp = 1;
	char x[n];
	char y[n];
	printf("Enter the string\n");
	scanf("%s",x);
	printf("Original String\n");
	for(i=0;i<n;i++)
	{
		printf("%c",x[i]);
		y[i]=x[i];
	}
	for(i=0;i<n;i++)
	{
		flag =0;
		for(j=0;j<n;j++)
		{
			if(x[i]==x[j])
			{
				flag = flag+1;
			}
		}
		for(j=0;j<n;j++)
		{
			if((flag % 2) !=0)
			{
				if(x[i]==y[j] && i!=j && temp!=x[i])
				{
					y[j]=0;
					
				}
			}
			else
			{
				if(x[i]==y[j])
				{
					y[j]=0;
				}
			}
		}
		temp = x[i];
		
	}
	printf("\nFinal String\n");
	for(j=0;j<n;j++)
	{
		if(y[j]!=0)
		{
			printf("%c",y[j]);
			count++;
		}
	}
	if(count==0)
	{
		printf("Empty String\n");
	}
}
