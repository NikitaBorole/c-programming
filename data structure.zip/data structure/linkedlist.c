#include <stdio.h>
#include <stdlib.h>

struct node
{
int info;
struct node *link;
};

int display(struct node *);
struct node* insert(int,struct node*);
/*struct node* insertend(int,struct node*,struct node*);*/

int main()
{
int data;
struct node *first, *second,*third;
first=(struct node *)malloc(sizeof(struct node));
second=(struct node *)malloc(sizeof(struct node));
third=(struct node *)malloc(sizeof(struct node));

first->info=1;
first->link=second;
second->info=2;
second->link=third;

third->info=3;
third->link=NULL;

display(first);
first=insert(10,first);
first=insert(20,first);
printf("After insertion\n");
display(first);


/*printf("insert at end: ");
scanf("%d", &data);
insertend(data);
displayend();*/
}

int display(struct node *first)
{
struct node *save;
save=first;
while(save!=NULL)
{
printf("%d ",save->info);
save=save->link;
}
}


struct node* insert(int x,struct node *first)
{
struct node *new;
new=(struct node *)malloc(sizeof(struct node));
if(new==NULL)
{
printf("overflow");
return first;
}
else
{
new->info=x;
if(first==NULL)
{
new->link=NULL;
return new;
}
else
{
new->link=first;
return new;
}
}
}

/*struct node insertend(int data,struct node *newnode, struct node *temp)
{

newNode = (struct node*)malloc(sizeof(struct node));

if(newNode == NULL)
{
printf("no allocat memeory");
}
 else
 {
newNode->data = data;
newNode->next = NULL; 

temp = head;

while(temp != NULL && temp->next != NULL)
temp = temp->next;

temp->next = newNode; 

printf("success\n");
}
}*/


























